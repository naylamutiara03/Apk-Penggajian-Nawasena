<!-- Footer -->
<footer class="text-black text-center py-4 mt-auto w-full border-t">
    <p class="text-sm md:text-base">Created by Nayla Mutiara &copy; <?php echo date("Y"); ?></p>
</footer>